import React from "react";
import { Outlet, Link } from "react-router-dom";
import "./navbar.css";

export default function Navbar() {
  return (
    <div>
      <nav>
        <ul>
          <li>
            <Link to="/validation">User</Link>
          </li>
          <li>
            <Link to="/map">Inspector</Link>
          </li>
          <li>
            <Link to="/verifyInspector">Admin</Link>
          </li>
        </ul>
      </nav>

      <Outlet />
    </div>
  );
}
