import React, { useState } from "react";

function VerifyInspector({ contract, provider, account }) {
  const [address, setAddress] = useState(0);
  const [aadhaarNumber, setAadhaarNumber] = useState("");

  function handleAddressChange(event) {
    const input = event.target.value;
    setAddress(input);
  }

  function handleAadhaarChange(event) {
    const input = event.target.value;
    setAadhaarNumber(input);
  }

  async function addInspector() {
    try {
      await contract.addInspector(address, aadhaarNumber);
    } catch (error) {
      console.log(error.message);
    }
  }

  return (
    <>
      <label>Inspector Address: </label>
      <input type="text" value={address} onChange={handleAddressChange} />
      <label>Inspector Aadhaar Number: </label>
      <input type="text" value={aadhaarNumber} onChange={handleAadhaarChange} />
      <button onClick={addInspector}>Add Inspector</button>
    </>
  );
}

export default VerifyInspector;
